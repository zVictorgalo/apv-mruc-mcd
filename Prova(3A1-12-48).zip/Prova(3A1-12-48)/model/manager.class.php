<?php 

    class Manager extends Conexao{

        public function insert_student($data){
            
            $pdo = parent::get_instance();

            $sql = "INSERT INTO aluno VALUES(null, :nome, :email, :cpf)";

            $statement = $pdo->prepare($sql);

            foreach($data as $key => $value){
                $statement->bindValue(":$key", $value);
                var_dump($key,$value);
            }

            var_dump($statement);

        $statement->execute();
        }

        public function list_student(){
            $pdo = parent::get_instance();
            $sql = 'SELECT * FROM aluno order by id desc';
            $statement = $pdo->query($sql);
            $statement->execute();

            return $statement->fetchAll();

        }

        public function list_student_by_id(){
            $pdo = parent::get_instance();
            $sql = 'SELECT * FROM aluno order by id desc';
            $statement = $pdo->query($sql);
            $statement->execute();

            return $statement->fetchAll();

        }

        public function delete_student($id){
            $pdo = parent::get_instance();
            $sql = "DELETE FROM aluno WHERE id = :id";
            $statement = $pdo->prepare($sql);
            $statement->bindValue(":id",$id);
            $statement->execute();
        }

        public function update_student($data){
            $pdo = parent::get_instance();
            $sql = "UPDATE aluno SET nome=:nome, email = :email, cpf = :cpf WHERE id =:id";
            
            var_dump($sql);
            $statement = $pdo->prepare($sql);
            foreach($data as $key => $value){
                $statement->bindValue(":$key", $value);
            }
            $statement->execute();
            
        }
        
    }

?>